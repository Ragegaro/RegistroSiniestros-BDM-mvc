<?php
require_once "models/Conexion.php";

class SiniestroM {
    private $_db;

    public function __construct() {
        $this->_db = new Conexion();
    }

    public function reportar($fecha, $hora, $direccion, $descripcion = null, $poliza) {
        $this->_db->conectar();
        $sql = "INSERT INTO siniestro (fecha, hora, direccion, descripcion, poliza_id) VALUES (?, ?, ?, ?, ?)";
        $stmt = $this->_db->conexion->prepare($sql);
        $resultado = $stmt->execute([$fecha, $hora, $direccion, $descripcion, $poliza]);
        $idInsertado = $resultado ? $this->_db->conexion->lastInsertId() : false;
        $this->_db->desconectar();
        return $idInsertado;
    }

    public function obtenerSiniestrosPorRol($idUsuario, $rolSlug) {
        $this->_db->conectar();
        $sql = "SELECT * FROM vListarSiniestros";
        $params = [];

        if ($rolSlug === 'ajustador') {
            $sql .= " WHERE ajustador_id = ?";
            $params[] = $idUsuario;
        } elseif ($rolSlug === 'asegurado') {
            $sql .= " WHERE Usuario = ?";
            $params[] = $idUsuario;
        } elseif (!in_array($rolSlug, ['supervisor', 'admin'], true)) {
            $sql .= " WHERE 1 = 0";
        }

        $sql .= " ORDER BY fecha DESC, id DESC";
        $stmt = $this->_db->conexion->prepare($sql);
        $stmt->execute($params);
        $resultados = $stmt->fetchAll(PDO::FETCH_OBJ);
        $this->_db->desconectar();
        return $resultados;
    }

    public function obtenerPorID($idSiniestro) {
        $this->_db->conectar();
        $sql = "SELECT * FROM vListarSiniestros WHERE id = ?";
        $stmt = $this->_db->conexion->prepare($sql);
        $stmt->execute([$idSiniestro]);
        $resultado = $stmt->fetch(PDO::FETCH_ASSOC);
        $this->_db->desconectar();
        return $resultado;
    }

    public function insertarMultimedia($tipo, $archivoBlob, $ruta, $idSiniestro) {
        $this->_db->conectar();
        $sql = "INSERT INTO multimedia (tipo, archivo, ruta, siniestro_id) VALUES (?, ?, ?, ?)";
        $stmt = $this->_db->conexion->prepare($sql);
        $resultado = $stmt->execute([$tipo, $archivoBlob, $ruta, $idSiniestro]);
        $this->_db->desconectar();
        return $resultado;
    }

    public function obtenerMultimediaPorSiniestro($idSiniestro) {
        $this->_db->conectar();
        $sql = "SELECT id, tipo, archivo, ruta FROM multimedia WHERE siniestro_id = ? ORDER BY id";
        $stmt = $this->_db->conexion->prepare($sql);
        $stmt->execute([$idSiniestro]);
        $resultados = $stmt->fetchAll(PDO::FETCH_OBJ);
        $this->_db->desconectar();
        return $resultados;
    }

    public function getHistorialEstatus($idSiniestro) {
        $this->_db->conectar();
        $sql = "
            SELECT h.id, h.fecha_actu, h.estatus_id, e.nombre AS estatus
            FROM historialestatus h
            INNER JOIN estatus e ON e.id = h.estatus_id
            WHERE h.siniestro_id = ?
            ORDER BY h.fecha_actu DESC, h.id DESC
        ";
        $stmt = $this->_db->conexion->prepare($sql);
        $stmt->execute([$idSiniestro]);
        $resultados = $stmt->fetchAll(PDO::FETCH_OBJ);
        $this->_db->desconectar();
        return $resultados;
    }

    public function obtenerEstatus() {
        $this->_db->conectar();
        $stmt = $this->_db->conexion->prepare("SELECT id, nombre FROM estatus ORDER BY id");
        $stmt->execute();
        $resultados = $stmt->fetchAll(PDO::FETCH_OBJ);
        $this->_db->desconectar();
        return $resultados;
    }

    public function cambiarEstatus($idSiniestro, $idEstatus) {
        $this->_db->conectar();
        try {
            $this->_db->conexion->beginTransaction();

            $stmtActual = $this->_db->conexion->prepare("SELECT estatus_id FROM siniestro WHERE id = ? FOR UPDATE");
            $stmtActual->execute([$idSiniestro]);
            $actual = $stmtActual->fetchColumn();
            if ($actual === false) {
                throw new RuntimeException('Siniestro no encontrado');
            }

            if ((string) $actual !== (string) $idEstatus) {
                $stmt = $this->_db->conexion->prepare("UPDATE siniestro SET estatus_id = ? WHERE id = ?");
                $stmt->execute([$idEstatus, $idSiniestro]);

                $stmtHistorial = $this->_db->conexion->prepare(
                    "INSERT INTO historialestatus (siniestro_id, estatus_id) VALUES (?, ?)"
                );
                $stmtHistorial->execute([$idSiniestro, $idEstatus]);
            }

            $this->_db->conexion->commit();
            $resultado = true;
        } catch (Throwable $e) {
            if ($this->_db->conexion && $this->_db->conexion->inTransaction()) {
                $this->_db->conexion->rollBack();
            }
            $resultado = false;
        }

        $this->_db->desconectar();
        return $resultado;
    }

    public function guardarEvaluacion($idSiniestro, $idAjustador, $diagnostico) {
        $this->_db->conectar();
        $sql = "
            INSERT INTO evaluacion (diagnostico, siniestro_id, ajustador_id)
            VALUES (?, ?, ?)
            ON DUPLICATE KEY UPDATE
                diagnostico = VALUES(diagnostico),
                ajustador_id = VALUES(ajustador_id),
                fecha_evaluacion = CURRENT_TIMESTAMP
        ";
        $stmt = $this->_db->conexion->prepare($sql);
        $resultado = $stmt->execute([$diagnostico, $idSiniestro, $idAjustador]);
        $this->_db->desconectar();
        return $resultado;
    }

    public function obtenerEvaluacion($idSiniestro) {
        $this->_db->conectar();
        $sql = "
            SELECT e.*, u.nombre AS nombre_ajustador, u.apellido_p AS apellido_ajustador
            FROM evaluacion e
            INNER JOIN usuario u ON u.id = e.ajustador_id
            WHERE e.siniestro_id = ?
            LIMIT 1
        ";
        $stmt = $this->_db->conexion->prepare($sql);
        $stmt->execute([$idSiniestro]);
        $resultado = $stmt->fetch(PDO::FETCH_ASSOC);
        $this->_db->desconectar();
        return $resultado ?: null;
    }

    public function getDashboardAdmin() {
        $this->_db->conectar();
        $datos = [];
        $datos['resumen_estatus'] = $this->_db->conexion->query("SELECT * FROM vDashboardAdmin")->fetchAll(PDO::FETCH_ASSOC);
        $datos['ajustadores'] = $this->_db->conexion->query("SELECT * FROM vListarAjustadores")->fetchAll(PDO::FETCH_ASSOC);
        $datos['clientes'] = $this->_db->conexion->query("SELECT * FROM vListarClientes LIMIT 10")->fetchAll(PDO::FETCH_ASSOC);
        $this->_db->desconectar();
        return $datos;
    }
}
?>
