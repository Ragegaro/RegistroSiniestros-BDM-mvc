# Cambios aplicados a la branch Dev

Esta copia integra los arreglos realizados durante las pruebas locales del proyecto.

## Flujo por roles
- Asegurado: reporta siniestros, consulta sus pólizas y sus propios siniestros.
- Ajustador: consulta únicamente los siniestros que tiene asignados y guarda/actualiza una evaluación.
- Supervisor: consulta todos los siniestros, ve el dashboard y cambia estatus.
- El inicio del supervisor ya no incrusta automáticamente el listado completo de siniestros.
- El navbar muestra únicamente las opciones correspondientes a cada rol.

## Siniestros
- Se corrigió el filtrado de siniestros por rol.
- El detalle valida que asegurados y ajustadores solo puedan abrir expedientes que les correspondan.
- Las evidencias BLOB continúan mostrándose en el detalle.
- La evaluación se guarda en la tabla `evaluacion` y puede actualizarse sin crear duplicados.
- El cambio de estatus actualiza `siniestro.estatus_id` y registra un movimiento en `historialestatus`.
- El historial muestra el nombre del estatus, no solamente su id.

## Interfaz
- Se trasladó el diseño visual usado durante las pruebas de la branch Main.
- Se corrigió el desbordamiento de aliases largos en la pantalla de perfil.
- Se conservaron los datos de dashboard disponibles en Dev con estilos compatibles.
- El CSS usa `?v=3` en el header para reducir problemas de caché durante las pruebas.

## SQL
- Se agregó la tabla `evaluacion` a `tablas.sql`.
- Se precargan los roles `asegurado`, `ajustador` y `supervisor`.
- Se precargan los estatus de prueba usados por la aplicación.
- `sp_validar_usuario` quedó corregido.
- `sp_registrar_usuario` busca el rol asegurado por `slug` y recibe la foto como LONGBLOB.
- `sp_InsertarPoliza` ahora inserta en `poliza` (singular) y coincide con el orden usado por PHP.
- `instalacion_completa.sql` reúne tablas, vistas, procedures y trigger de asignación automática.
- El historial de estatus se registra desde PHP; por eso no se crea el trigger de historial para evitar filas duplicadas.

## Nota
El proyecto conserva MD5 porque la base y el flujo actual ya están construidos con ese formato. Para producción debe migrarse a `password_hash()` y `password_verify()`.
