# Registro de Siniestros — Seguros FCFM (Dev corregida)

Aplicación académica en PHP/MySQL con arquitectura MVC para registrar y dar seguimiento a siniestros, pólizas, evidencias, evaluaciones y estatus.

## Instalación rápida
1. Copia la carpeta dentro de `htdocs`.
2. Inicia Apache y MySQL en XAMPP.
3. En phpMyAdmin importa `z database/instalacion_completa.sql` para una instalación limpia, o utiliza tu respaldo exportado de `bdm_aseguradora` si deseas conservar tus datos de prueba.
4. Abre el proyecto desde `localhost`. `config.php` calcula automáticamente el nombre de la carpeta del proyecto.

## Roles
- **Asegurado:** reporta y consulta sus siniestros y pólizas.
- **Ajustador:** consulta expedientes asignados y registra la evaluación.
- **Supervisor:** consulta todos los expedientes, dashboard y cambios de estatus.

## Archivos principales
- `controllers/` controladores MVC.
- `models/` consultas y persistencia.
- `views/` interfaz.
- `assets/css/style.css` diseño principal.
- `z database/instalacion_completa.sql` instalación limpia de base de datos.
- `CAMBIOS_APLICADOS.md` resumen de correcciones integradas.

## Nota de seguridad
La aplicación mantiene MD5 para conservar compatibilidad con el proyecto académico existente. No debe usarse así en producción.
