<?php
require_once "models/siniestro/SiniestroM.php";

class SiniestroC {
    private $modelo;

    public function __construct() {
        $this->modelo = new SiniestroM();
    }

    private function exigirSesion() {
        if (!isset($_SESSION['id_usuario'])) {
            header("Location: index.php");
            exit;
        }
    }

    private function puedeVerSiniestro($siniestro) {
        if (!$siniestro) return false;
        $rol = $_SESSION['rol_slug'] ?? '';
        $id = (int) ($_SESSION['id_usuario'] ?? 0);

        if (in_array($rol, ['supervisor', 'admin'], true)) return true;
        if ($rol === 'asegurado') return (int) $siniestro['Usuario'] === $id;
        if ($rol === 'ajustador') return (int) ($siniestro['ajustador_id'] ?? 0) === $id;
        return false;
    }

    public function mostrarFormulario() {
        $this->exigirSesion();
        if (($_SESSION['rol_slug'] ?? '') !== 'asegurado') {
            header("Location: index.php?page=misSiniestros");
            exit;
        }

        require_once "models/poliza/PolizaM.php";
        $modeloPoliza = new PolizaM();
        $misPolizas = $modeloPoliza->verPolizas($_SESSION['id_usuario']);
        $misPolizas = is_array($misPolizas) ? $misPolizas : [];

        require "views/layouts/header.php";
        require "views/layouts/navbar.php";
        require "views/siniestros/reporteV.php";
        require "views/layouts/footer.php";
    }

    public function agregarSiniestro() {
        $this->exigirSesion();
        if (($_SESSION['rol_slug'] ?? '') !== 'asegurado' || $_SERVER['REQUEST_METHOD'] !== 'POST') {
            header("Location: index.php?page=misSiniestros");
            exit;
        }

        $idSiniestro = $this->modelo->reportar(
            $_POST['fecha'] ?? '',
            $_POST['hora'] ?? '',
            $_POST['ubicacion'] ?? '',
            $_POST['descripcion'] ?? null,
            $_POST['SelectPoliza'] ?? 0
        );

        if ($idSiniestro) {
            if (isset($_FILES['evidencias']) && !empty($_FILES['evidencias']['name'][0])) {
                $this->procesarArchivosMultimedia($idSiniestro, $_FILES['evidencias']);
            }
            header("Location: index.php?page=misSiniestros&success=1");
            exit;
        }

        header("Location: index.php?page=report&error=1");
        exit;
    }

    public function listarSiniestros() {
        $this->exigirSesion();
        $idUsuario = (int) $_SESSION['id_usuario'];
        $rolUsuario = $_SESSION['rol_slug'] ?? '';
        $misSiniestros = $this->modelo->obtenerSiniestrosPorRol($idUsuario, $rolUsuario);
        $misSiniestros = is_array($misSiniestros) ? $misSiniestros : [];

        require "views/layouts/header.php";
        require "views/layouts/navbar.php";
        require "views/siniestros/listarSiniestrosV.php";
        require "views/layouts/footer.php";
    }

    public function verDetalledSiniestro() {
        $this->exigirSesion();
        $idSiniestro = isset($_GET['id']) ? (int) $_GET['id'] : 0;
        $siniestro = $idSiniestro > 0 ? $this->modelo->obtenerPorID($idSiniestro) : false;

        if (!$siniestro) {
            http_response_code(404);
            echo "Siniestro no encontrado.";
            exit;
        }

        if (!$this->puedeVerSiniestro($siniestro)) {
            header("Location: index.php?page=misSiniestros");
            exit;
        }

        $siniestro['multimedia'] = $this->modelo->obtenerMultimediaPorSiniestro($idSiniestro);
        $historial = $this->modelo->getHistorialEstatus($idSiniestro);
        $estatusDisponibles = $this->modelo->obtenerEstatus();
        $evaluacion = $this->modelo->obtenerEvaluacion($idSiniestro);

        require "views/layouts/header.php";
        require "views/layouts/navbar.php";
        require "views/siniestros/detalle.php";
        require "views/layouts/footer.php";
    }

    public function guardarEvaluacion() {
        $this->exigirSesion();
        $rol = $_SESSION['rol_slug'] ?? '';
        if (!in_array($rol, ['ajustador', 'supervisor'], true) || $_SERVER['REQUEST_METHOD'] !== 'POST') {
            header("Location: index.php?page=misSiniestros");
            exit;
        }

        $idSiniestro = isset($_POST['id_siniestro']) ? (int) $_POST['id_siniestro'] : 0;
        $diagnostico = trim($_POST['diagnostico'] ?? '');
        $siniestro = $idSiniestro > 0 ? $this->modelo->obtenerPorID($idSiniestro) : false;

        if (!$siniestro || !$this->puedeVerSiniestro($siniestro) || $diagnostico === '') {
            header("Location: index.php?page=detalle&id=" . $idSiniestro . "&error=evaluacion");
            exit;
        }

        $resultado = $this->modelo->guardarEvaluacion(
            $idSiniestro,
            (int) $_SESSION['id_usuario'],
            $diagnostico
        );

        header("Location: index.php?page=detalle&id=" . $idSiniestro . ($resultado ? "&success=evaluacion" : "&error=evaluacion"));
        exit;
    }

    public function actualizarEstatus() {
        $this->exigirSesion();
        $rol = $_SESSION['rol_slug'] ?? '';
        if (!in_array($rol, ['supervisor', 'admin'], true) || $_SERVER['REQUEST_METHOD'] !== 'POST') {
            header("Location: index.php?page=misSiniestros");
            exit;
        }

        $idSiniestro = isset($_POST['id_siniestro']) ? (int) $_POST['id_siniestro'] : 0;
        $idEstatus = isset($_POST['estatus_id']) ? (int) $_POST['estatus_id'] : 0;

        if ($idSiniestro <= 0 || $idEstatus <= 0) {
            header("Location: index.php?page=detalle&id=" . $idSiniestro . "&error=estatus");
            exit;
        }

        $resultado = $this->modelo->cambiarEstatus($idSiniestro, $idEstatus);
        header("Location: index.php?page=detalle&id=" . $idSiniestro . ($resultado ? "&success=estatus" : "&error=estatus"));
        exit;
    }

    private function procesarArchivosMultimedia($idSiniestro, $archivos) {
        $carpetaBase = "uploads/siniestros/SIN-" . $idSiniestro . "/";
        $total = is_array($archivos['name'] ?? null) ? count($archivos['name']) : 0;

        for ($i = 0; $i < $total; $i++) {
            if (($archivos['error'][$i] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_OK) continue;

            $tmpName = $archivos['tmp_name'][$i];
            $type = $archivos['type'][$i] ?? '';
            $nombreOriginal = $archivos['name'][$i] ?? '';
            $extension = strtolower(pathinfo($nombreOriginal, PATHINFO_EXTENSION));

            if (strpos($type, 'video/') === 0) {
                if (!is_dir($carpetaBase)) mkdir($carpetaBase, 0777, true);
                $nuevoNombre = "video_" . uniqid('', true) . ($extension ? "." . $extension : '');
                $rutaFinal = $carpetaBase . $nuevoNombre;
                if (move_uploaded_file($tmpName, $rutaFinal)) {
                    $this->modelo->insertarMultimedia('Video', null, $rutaFinal, $idSiniestro);
                }
            } elseif (strpos($type, 'image/') === 0) {
                $contenidoBlob = file_get_contents($tmpName);
                $this->modelo->insertarMultimedia('Foto', $contenidoBlob, null, $idSiniestro);
            }
        }
    }
}
?>
