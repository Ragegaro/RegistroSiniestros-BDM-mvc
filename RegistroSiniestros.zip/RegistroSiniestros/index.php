<?php
require "config.php";
if (session_status() === PHP_SESSION_NONE) session_start();
$page = isset($_GET['page']) ? $_GET['page'] : 'logIn';

switch ($page) {
    case 'logIn':
        require "controllers/usuario/UsuarioC.php";
        (new UsuarioC())->index();
        break;
    case 'logInAuth':
        require "controllers/usuario/UsuarioC.php";
        (new UsuarioC())->logIn();
        break;
    case 'logout':
        require "controllers/usuario/UsuarioC.php";
        UsuarioC::logOut();
        break;
    case 'sigIn':
        require_once "controllers/usuario/UsuarioC.php";
        (new UsuarioC())->mostrarRegistro();
        break;
    case 'sigInAuth':
        require_once "controllers/usuario/UsuarioC.php";
        (new UsuarioC())->procesarRegistro();
        break;

    case 'supervisor':
    case 'ajustador':
    case 'asegurado':
        require_once "controllers/usuario/UsuarioC.php";
        (new UsuarioC())->mostrarPerfil();
        break;
    case 'miPerfil':
        require_once "controllers/usuario/UsuarioC.php";
        (new UsuarioC())->EditarPerfil();
        break;
    case 'editarPerfil':
        require_once "controllers/usuario/UsuarioC.php";
        (new UsuarioC())->procesarEdicion();
        break;

    case 'report':
        require_once "controllers/siniestro/SiniestroC.php";
        (new SiniestroC())->mostrarFormulario();
        break;
    case 'guardarSiniestro':
        require_once "controllers/siniestro/SiniestroC.php";
        (new SiniestroC())->agregarSiniestro();
        break;
    case 'misSiniestros':
        require_once "controllers/siniestro/SiniestroC.php";
        (new SiniestroC())->listarSiniestros();
        break;
    case 'detalle':
        require_once "controllers/siniestro/SiniestroC.php";
        (new SiniestroC())->verDetalledSiniestro();
        break;
    case 'guardarEvaluacion':
    case 'guardarEdicionEvaluacion':
        require_once "controllers/siniestro/SiniestroC.php";
        (new SiniestroC())->guardarEvaluacion();
        break;
    case 'actualizarEstatus':
        require_once "controllers/siniestro/SiniestroC.php";
        (new SiniestroC())->actualizarEstatus();
        break;

    case 'polizas':
        require "controllers/poliza/PolizaC.php";
        (new PolizaC())->listarPolizas();
        break;

    case 'guardarAuto':
        require_once "controllers/poliza/AutoC.php";
        (new AutoC())->agregarAuto();
        break;
    case 'agregarAuto':
        require "views/layouts/header.php";
        require "views/polizas/autos/agregarAutoV.php";
        require "views/layouts/footer.php";
        break;

    default:
        require "controllers/usuario/UsuarioC.php";
        (new UsuarioC())->index();
        break;
}
